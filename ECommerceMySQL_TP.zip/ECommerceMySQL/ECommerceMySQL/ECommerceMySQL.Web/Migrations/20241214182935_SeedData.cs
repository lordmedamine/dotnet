﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace ECommerceMySQL.Web.Migrations
{
    /// <inheritdoc />
    public partial class SeedData : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "Id", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "Electronic devices and gadgets", "Electronics" },
                    { 2, "Fashion and apparel", "Clothing" }
                });

            migrationBuilder.InsertData(
                table: "Products",
                columns: new[] { "Id", "CategoryId", "CreatedAt", "Description", "ImageUrl", "Name", "Price", "StockQuantity", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, 1, new DateTime(2024, 12, 14, 18, 29, 34, 819, DateTimeKind.Utc).AddTicks(4500), "Latest model smartphone with advanced features", "https://via.placeholder.com/300", "Smartphone", 699.99m, 50, null },
                    { 2, 1, new DateTime(2024, 12, 14, 18, 29, 34, 819, DateTimeKind.Utc).AddTicks(4660), "High-performance laptop for professionals", "https://via.placeholder.com/300", "Laptop", 1299.99m, 30, null },
                    { 3, 2, new DateTime(2024, 12, 14, 18, 29, 34, 819, DateTimeKind.Utc).AddTicks(4670), "Comfortable cotton t-shirt", "https://via.placeholder.com/300", "T-Shirt", 19.99m, 100, null }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Products",
                keyColumn: "Id",
                keyValue: 3);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: 2);
        }
    }
}
