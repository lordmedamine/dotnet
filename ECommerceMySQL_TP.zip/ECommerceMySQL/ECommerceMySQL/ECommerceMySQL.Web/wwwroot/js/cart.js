// Handle add to cart functionality
function addToCart(productId, quantity = 1) {
    // Check if user is authenticated
    const isAuthenticated = document.body.classList.contains('user-authenticated');
    
    if (!isAuthenticated) {
        // Redirect to login page with return URL
        const currentUrl = encodeURIComponent(window.location.href);
        window.location.href = `/Account/Login?returnUrl=${currentUrl}`;
        return;
    }

    // Submit the form to add item to cart
    const form = document.createElement('form');
    form.method = 'POST';
    form.action = '/Cart/AddToCart';

    // Add antiforgery token
    const tokenElement = document.querySelector('input[name="__RequestVerificationToken"]');
    if (tokenElement) {
        const tokenInput = document.createElement('input');
        tokenInput.type = 'hidden';
        tokenInput.name = '__RequestVerificationToken';
        tokenInput.value = tokenElement.value;
        form.appendChild(tokenInput);
    }

    const productIdInput = document.createElement('input');
    productIdInput.type = 'hidden';
    productIdInput.name = 'productId';
    productIdInput.value = productId;

    const quantityInput = document.createElement('input');
    quantityInput.type = 'hidden';
    quantityInput.name = 'quantity';
    quantityInput.value = quantity;

    form.appendChild(productIdInput);
    form.appendChild(quantityInput);
    document.body.appendChild(form);
    form.submit();
}

// Initialize Bootstrap dropdowns
document.addEventListener('DOMContentLoaded', function() {
    // No need for custom dropdown handling as we're using Bootstrap's dropdown
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
