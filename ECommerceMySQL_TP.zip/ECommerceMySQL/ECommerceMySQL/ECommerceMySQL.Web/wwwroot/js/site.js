// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Dark mode functionality
let darkMode = localStorage.getItem('darkMode') === 'true';

function toggleDarkMode() {
    darkMode = !darkMode;
    localStorage.setItem('darkMode', darkMode);
    updateTheme();
}

function updateTheme() {
    if (darkMode) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }
}

// Initialize theme
document.addEventListener('DOMContentLoaded', () => {
    updateTheme();
    
    // Create dark mode toggle button if it doesn't exist
    if (!document.querySelector('.dark-mode-toggle')) {
        const toggle = document.createElement('button');
        toggle.className = 'dark-mode-toggle';
        toggle.innerHTML = '<i class="bi bi-moon-fill"></i>';
        toggle.onclick = toggleDarkMode;
        document.body.appendChild(toggle);
    }
});

// Search and filter functionality
let debounceTimeout;

function debounce(func, wait) {
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(debounceTimeout);
            func(...args);
        };
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(later, wait);
    };
}

function filterProducts() {
    const searchQuery = document.getElementById('searchInput').value.toLowerCase();
    const minPrice = parseFloat(document.getElementById('minPrice').value) || 0;
    const maxPrice = parseFloat(document.getElementById('maxPrice').value) || Infinity;
    
    const products = document.querySelectorAll('.product-card');
    
    products.forEach(product => {
        const title = product.querySelector('.card-title').textContent.toLowerCase();
        const description = product.querySelector('.card-text').textContent.toLowerCase();
        const price = parseFloat(product.querySelector('.product-price').dataset.price);
        
        const matchesSearch = title.includes(searchQuery) || description.includes(searchQuery);
        const matchesPrice = price >= minPrice && price <= maxPrice;
        
        if (matchesSearch && matchesPrice) {
            product.style.display = '';
            // Add a subtle animation
            product.style.opacity = '1';
            product.style.transform = 'scale(1)';
        } else {
            product.style.display = 'none';
            product.style.opacity = '0';
            product.style.transform = 'scale(0.95)';
        }
    });
}

// Cart functionality
function updateQuantity(productId, change) {
    const quantityInput = document.querySelector(`#quantity-${productId}`);
    let newQuantity = parseInt(quantityInput.value) + change;
    
    if (newQuantity < 1) newQuantity = 1;
    
    quantityInput.value = newQuantity;
    updateCartItemTotal(productId);
}

function updateCartItemTotal(productId) {
    const quantityInput = document.querySelector(`#quantity-${productId}`);
    const priceElement = document.querySelector(`#price-${productId}`);
    const totalElement = document.querySelector(`#total-${productId}`);
    
    const quantity = parseInt(quantityInput.value);
    const price = parseFloat(priceElement.dataset.price);
    const total = quantity * price;
    
    totalElement.textContent = `$${total.toFixed(2)}`;
    updateCartTotal();
}

function updateCartTotal() {
    const totals = document.querySelectorAll('[id^="total-"]');
    const cartTotal = Array.from(totals)
        .reduce((sum, el) => sum + parseFloat(el.textContent.replace('$', '')), 0);
    
    document.querySelector('#cart-total').textContent = `$${cartTotal.toFixed(2)}`;
}

// Initialize search and filter listeners
document.addEventListener('DOMContentLoaded', () => {
    const searchInput = document.getElementById('searchInput');
    const minPriceInput = document.getElementById('minPrice');
    const maxPriceInput = document.getElementById('maxPrice');
    
    if (searchInput && minPriceInput && maxPriceInput) {
        const debouncedFilter = debounce(filterProducts, 300);
        searchInput.addEventListener('input', debouncedFilter);
        minPriceInput.addEventListener('input', debouncedFilter);
        maxPriceInput.addEventListener('input', debouncedFilter);
    }
});
